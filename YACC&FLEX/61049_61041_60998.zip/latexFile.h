#ifndef __LATEXFILE
#define __LATEXFILE

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "linkedlist/linkedlist.h"
#include "structs.h"

void criaPaginaPDF(LinkedList, Report, LinkedList) ;

#endif