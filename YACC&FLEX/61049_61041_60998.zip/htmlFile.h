#ifndef __HTMLFILE
#define __HTMLFILE

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "linkedlist/linkedlist.h"
#include "structs.h"

void criaPagina(Report, LinkedList, LinkedList, LinkedList, LinkedList,LinkedList) ;

#endif